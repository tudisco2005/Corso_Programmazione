/*
Estendere l’esercizio precedente in maniera tale che, oltre ai caratteri, possa avere
in ingresso oggetti di altro tipo come ad esempio Vett, Frazioni, eccetera. Per
farlo, utilizzare l’oggetto generico Object.
Che tipo di ADT rappresenta questa lista? Quale metodo devono avere que-
sti oggetti al fine di poter eliminare i doppi? Pensate prima alla struttura del
programma e delle classi prima di iniziare l’implementazione.
*/

