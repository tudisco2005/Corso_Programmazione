package mygeometry;

public class Vett {
    // Attributi privati
    protected double x;
    protected double y;

    // Costruttore di default
    public Vett() {
        this.x = 0;
        this.y = 0;
    }

    // Costruttore con coordinate specificate
    public Vett(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // Costruttore che copia un altro vettore
    public Vett(Vett altroVett) {
        this.x = altroVett.x;
        this.y = altroVett.y;
    }

    // Getter e setter per le coordinate
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    // Metodo per muovere il punto
    public void muovi(double deltaX, double deltaY) {
        this.x += deltaX;
        this.y += deltaY;
    }

    // Calcola la distanza dall'origine (0, 0)
    public double distanzaOrigine() {
        return Math.sqrt(x * x + y * y);
    }

    // Metodo per sommare un altro vettore
    public Vett somma(Vett altroVett) {
        return new Vett(this.x + altroVett.x, this.y + altroVett.y);
    }

    // Rappresentazione testuale del vettore
    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
    
    // Metodo per confrontare due vettori
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vett altroVett = (Vett) obj;
        return x == altroVett.x && y == altroVett.y;
    }
}