package mygeometry;

public class Vett3d extends Vett{
    protected double z;

    public Vett3d(double x, double y, double z) {
        super(x,y);
        this.z = z;
    }

    public Vett3d() {
        super();
        this.z = z;
    }

    public double getZ() {
        return z;
    }

    // Metodo per muovere il punto
    public void muovi(double deltaX, double deltaY, double deltaZ) {
        this.x += deltaX;
        this.y += deltaY;
        this.z += deltaZ;
    }

    // Calcola la distanza dall'origine (0, 0, 0)
    @Override
    public double distanzaOrigine() {
        return Math.sqrt(x * x + y * y + z * z);
    }

    // Metodo per sommare un altro vettore e ritorna un nuovo vettore
    public Vett3d somma(Vett3d altroVett) {
        return new Vett3d(this.x + altroVett.x, this.y + altroVett.y, this.z + altroVett.z);
    }

    // Rappresentazione testuale del vettore
    @Override
    public String toString() {
        return "(" + x + ", " + y + ", " + z + ")";
    }
    
    // Metodo per confrontare due vettori
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Vett3d altroVett = (Vett3d) obj;
        return x == altroVett.x && y == altroVett.y && z == altroVett.z;
    }
}