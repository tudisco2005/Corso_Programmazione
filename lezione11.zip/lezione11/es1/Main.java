/*
A partire dalla classe Vett, che rappresenta un vettore/punto bidimensionale,
estenderla per creare una classe che rappresenti vettori/punti in tre dimensioni.
Usare la visibilità protected e overriding dei metodi, se possibile
*/

import mygeometry.*;

public class Main {
    public static void main(String[] args) {
        Vett a = new Vett(1,2);
        Vett b = new Vett(32,4);

        System.out.println(a);
        System.out.println(b);
        System.out.println(a.somma(b));


        Vett3d c = new Vett3d(1,2,3);
        Vett3d d = new Vett3d(10,20,30);

        System.out.println(c);
        System.out.println(d);
        System.out.println(c.somma(d));
    }
}