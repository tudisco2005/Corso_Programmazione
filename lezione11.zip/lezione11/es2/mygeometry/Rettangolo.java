package mygeometry;

public class Rettangolo {
    protected Vett orig;  // Punto di origine del rettangolo (angolo inferiore sinistro)
    protected double base;  // Larghezza del rettangolo
    protected double height;  // Altezza del rettangolo
    protected double angle;  // Angolo di rotazione del rettangolo rispetto all'asse x

    // Costruttore per inizializzare il rettangolo con origine, base, altezza e angolo
    public Rettangolo(Vett orig, double base, double height, double angle) {
        this.orig = orig;
        this.base = base;
        this.height = height;
        this.angle = angle;
    }

    // Metodo per calcolare l'area del rettangolo
    public double area() {
        return base * height;
    }

    // Metodo per calcolare il perimetro del rettangolo
    public double perimetro() {
        return 2 * (base + height);
    }

    // Metodo per ottenere la rappresentazione del rettangolo
    @Override
    public String toString() {
        return "Rettangolo [origine=" + orig + ", base=" + base + ", altezza=" + height + ", angolo=" + angle + " gradi]";
    }

    // Metodo per spostare il rettangolo di dx e dy
    public void muovi(double dx, double dy) {
        orig.muovi(dx, dy);
    }

    // Metodo per ruotare il rettangolo di un certo angolo
    public void ruota(double angolo) {
        this.angle += angolo;
    }
}
