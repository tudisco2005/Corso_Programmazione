/*
Definire la classe Rettangolo. Per questa classe definire i metodi getter,
setter, equals, toString, ecc. Definire poi la classe Quadrato. Che relazione
dovete utilizzare per queste due classi?
Come è definito un rettangolo? Il costruttore deve verificare che tale proprietà
sia rispettata. Lo stesso vale per quadrato.
Testarle con un main adatto e facendo delle operazioni semplice, come calcolare
area e perimetro. Appoggiarsi sui concetti di Vett e Linea, nel caso ve ne fosse
bisogno.
Area e perimetro devono essere attributi di rettangolo, e restituiti tramite un
getter, o calcolati al momento tramite una apposita funzione? Quali sono gli
svantaggi e i vantaggi di entrambe le implementazioni?
*/
import mygeometry.*;

public class Main {
    public static void main(String[] args) {
        // Creiamo un rettangolo con origine (0, 0), base 4, altezza 5 e angolo di rotazione 30 gradi
        Vett origine = new Vett(0, 0);
        Rettangolo rettangolo = new Rettangolo(origine, 4, 5, 30);

        // Stampiamo le informazioni sul rettangolo
        System.out.println(rettangolo);
        System.out.println("Area: " + rettangolo.area());  // Area: 20
        System.out.println("Perimetro: " + rettangolo.perimetro());  // Perimetro: 18

        // Spostiamo il rettangolo e stampiamo la nuova posizione
        rettangolo.muovi(2, 3);
        System.out.println("Dopo lo spostamento: " + rettangolo);

        // Ruotiamo il rettangolo e stampiamo la nuova orientazione
        rettangolo.ruota(15);
        System.out.println("Dopo la rotazione: " + rettangolo);

        // Creiamo un quadrato con lato 5
        Quadrato quadrato = new Quadrato(5);

        // Stampiamo le informazioni sul quadrato
        System.out.println(quadrato);  // Quadrato [lato=5.0, posizione=(0.0, 0.0), angolo=0.0 gradi]
        System.out.println("Area: " + quadrato.area());  // Area: 25.0
        System.out.println("Perimetro: " + quadrato.perimetro());  // Perimetro: 20.0

        // Modifichiamo il lato del quadrato e stampiamo di nuovo
        quadrato.setLato(10);
        System.out.println("Dopo aver cambiato il lato: " + quadrato);
        System.out.println("Nuova area: " + quadrato.area());  // Area: 100.0
        System.out.println("Nuovo perimetro: " + quadrato.perimetro());  // Perimetro: 40.0
    }
}