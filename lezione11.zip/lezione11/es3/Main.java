/*
Definire una classe astratta Figura, che racchiuda il concetto ripreso dalle classi
definite fino ad ora, come Cerchio, Rettangolo e Quadrato.
La classe Rettangolo può derivare direttamente da Figura o, in alternativa,
può derivare dalla classe Quadrilatero; nel secondo caso, un Rettangolo
è una versione specifica di Quadrilatero. Il vostro programma potrebbe
voler gestire diversi tipi di quadrilateri come Quadrato, Parallelogramma,
Trapezio. In fase di design del vostro programma, scegliete quali classi
rappresentare, quale è la loro gerarchia.

Tale classe deve avere dei metodi astratti per il calcolo di perimetro ed area. Testare
questa classe mediante un main che chieda all’utente di gestire un array di 10
figure, chiamandone i metodi, e istanziandole secondo quanto inserito dall’utente.
Viene chiesto all’utente cosa creare, e quindi verrà istanziato mediante il costruttore
relativo l’oggetto richiesto.
figure avvenga senza input da utente (quindi scritto direttamente nel codice)
*/

import mygeometry.*;

public class Main {
    public static void main(String[] args) {
        // Creiamo un array di 10 figure
        Figura[] figure = new Figura[5];

        // Inizializziamo alcune figure
        figure[0] = new Cerchio(5);
        figure[1] = new Rettangolo(4, 6);
        figure[2] = new Quadrato(4);
        figure[3] = new Cerchio(35);
        figure[4] = new Rettangolo(44, 62);
        


        // Stampa delle figure
        for (Figura f : figure) {
            System.out.println(f);
            System.out.println("Area: " + f.area());
            System.out.println("Perimetro: " + f.perimetro());
            System.out.println();
        }
    }
}