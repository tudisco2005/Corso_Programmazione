package mygeometry;

public class Linea extends Vett {
    protected Vett a;
    protected Vett b;

    public Linea(double x1, double y1, double x2, double y2) {
        this.a = new Vett(x1,y1);
        this.b = new Vett(x2,y2);
    }

    public Linea(Vett a, Vett b) {
        this.a = a;
        this.b = b;
    }

    @Override
    toString() {
        return a + " --- " + b
    }
}