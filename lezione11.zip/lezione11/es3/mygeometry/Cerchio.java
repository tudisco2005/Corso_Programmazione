package mygeometry;

public class Cerchio extends Figura {
    private double raggio;
    private Vett centro;

    public Cerchio(double raggio) {
        this.raggio = raggio;
        this.centro = new Vett(0,0); 
    }

    public Cerchio(Vett centro, double raggio) {
        this.raggio = raggio;
        this.centro = centro; 
    }

    @Override
    public double area() {
        return Math.PI * raggio * raggio; // Area di un cerchio: πr²
    }

    @Override
    public double perimetro() {
        return 2 * Math.PI * raggio; // Perimetro di un cerchio: 2πr
    }

    @Override
    public String toString() {
        return "Cerchio [raggio=" + raggio + "]";
    }
}
