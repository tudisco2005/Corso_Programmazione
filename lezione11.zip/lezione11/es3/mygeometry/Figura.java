package mygeometry;

public abstract class Figura {
    public abstract double perimetro();
    public abstract double area();
    @Override
    public abstract String toString();
}