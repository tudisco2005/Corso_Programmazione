package mygeometry;

public class Quadrato extends Rettangolo {
    
    // Costruttore che accetta la lunghezza del lato
    public Quadrato(double lato) {
        // Chiamata al costruttore della classe base Rettangolo
        super(new Vett(0, 0), lato, lato, 0);  // Quadrato ha base e altezza uguali
    }

    // Metodo per ottenere il lato del quadrato
    public double getLato() {
        return base;  // Poiché base = altezza per un quadrato
    }

    // Metodo per modificare il lato del quadrato
    public void setLato(double lato) {
        this.base = lato;   // Assegna la stessa lunghezza sia alla base che all'altezza
        this.height = lato; // Poiché base = altezza in un quadrato
    }

    // Metodo per calcolare l'area del quadrato
    @Override
    public double area() {
        return base * base; // Area di un quadrato: lato^2
    }

    // Metodo per calcolare il perimetro del quadrato
    @Override
    public double perimetro() {
        return 4 * base; // Perimetro di un quadrato: 4 * lato
    }

    @Override
    public String toString() {
        return "Quadrato [lato=" + base + ", posizione=" + orig + ", angolo=" + angle + " gradi]";
    }
}
